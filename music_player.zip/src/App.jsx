import React, { useState } from "react";
import "./App.css";
import { FaPlay, FaPause, FaStepForward, FaStepBackward } from "react-icons/fa";

const songs = [
  { id: 1, title: "Song 1", src: "/music/song1.mp3" },
  { id: 2, title: "Song 2", src: "/music/song2.mp3" },
  { id: 3, title: "Song 3", src: "/music/song3.mp3" },
];

const Musicplayer = () => {
  const [currentSong, setCurrentSong] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = React.useRef(null);

  const playSong = (song) => {
    if (currentSong?.id === song.id && isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      setCurrentSong(song);
      setIsPlaying(true);
      setTimeout(() => audioRef.current.play(), 100);
    }
  };

  const nextSong = () => {
    if (currentSong) {
      const currentIndex = songs.findIndex((s) => s.id === currentSong.id);
      const nextIndex = (currentIndex + 1) % songs.length;
      playSong(songs[nextIndex]);
    }
  };

  const prevSong = () => {
    if (currentSong) {
      const currentIndex = songs.findIndex((s) => s.id === currentSong.id);
      const prevIndex = (currentIndex - 1 + songs.length) % songs.length;
      playSong(songs[prevIndex]);
    }
  };

  return (
    <div className="music-container">
      <div className="sidebar">
        <h2>Music </h2>
        <ul>
          <li>Home</li>
          <li>Search</li>
          <li>Your Library</li>
        </ul>
      </div>
      <div className="main-content">
        <h1>Now Playing</h1>
        <div className="song-list">
          {songs.map((song) => (
            <div key={song.id} className="song-item" onClick={() => playSong(song)}>
              <span>{song.title}</span>
              <button className="play-btn">
                {currentSong?.id === song.id && isPlaying ? <FaPause /> : <FaPlay />}
              </button>
            </div>
          ))}
        </div>
        <div className="player-controls">
          <button className="control-btn" onClick={prevSong}><FaStepBackward /></button>
          <button className="control-btn" onClick={() => playSong(currentSong)}>
            {isPlaying ? <FaPause /> : <FaPlay />}
          </button>
          <button className="control-btn" onClick={nextSong}><FaStepForward /></button>
        </div>
      </div>
      {currentSong && <audio ref={audioRef} src={currentSong.src} onEnded={nextSong} />}
    </div>
  );
};

export default Musicplayer;
